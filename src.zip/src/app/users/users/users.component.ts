import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiService } from 'src/app/services/api.service';
import { User } from '../user';
@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
  users:User[]=[] ;

  constructor(private apiService: ApiService) {
    
    
}
 
  ngOnInit(): void {
    this.apiService.getAllusers().subscribe((data)=> {
      this.users=data;
    });

  }


}
